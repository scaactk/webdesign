
$(function(){

    $(".js_slide .roll").slide({
        css: {"width": 960, "height": 445},
        config: {"time": 5000, "type": "left", "speed": 800,"button":true,"butArr":".js_slide .roll .ui_1 li"},
        completes:function(o){
          $(".roll").hover(function(){
               $(".J_ui_butPost_a,.J_ui_butPost_b").show();
          },function(){
               $(".J_ui_butPost_a,.J_ui_butPost_b").hide();
          });
        },
        before:function(o){
            $(".roll").find(".textdiv_in").hide(0);
            $(".roll").find(".textdiv_in").eq(o).show()
        }
    });

    $(".js_r_box .roll").slide({
        css: {"width": 305, "height": 415},
        config: {"time": 5000, "type": "left", "speed": 800,"button":true,"butArr":".js_r_box .roll .ui_1 li"}
    });

    //teamVs.init();
    //cupArea.init();
});

!(function($) {

    var picScroll = function() {
        var arg = arguments,
        defaults = {
            css: {"width": 637, "height": 255},
            config: {"time": 3000, "type": "fade", "speed": 800, "button": false,"butArr":".roll .ui_1 li"},
            before:function(data){
            },
            after:function(data){
            }
        };
        return this.each(function() {
            var $this = $(this),
            $$ = function(a) {
                return $this.find(a)
            },
            animates = {
                list: 0,
                options: ["top", "left", "fade"],
                animated:false,
                init: function() {
                    this.arrays = [];
                    this.arrays[0] = $.extend(true,{}, defaults, arguments[0] || {});
                    this.ul = $$(".uiRoll");
                    this.li = $$(".uiRoll li");
                    this.but = this.arrays[0].config.butArr;
                    if(this.options.index(this.arrays[0].config.type) !== -1){
                        for (var i = 0; i < this.arrays.length; i++) {
                            switch (typeof this.arrays[i]) {
                                case 'object':
                                    $this.css(this.arrays[i].css);
                                    this.li.css(this.arrays[i].css)
                                    this.returnBefore = this.arrays[i].before;
                                    this.returnAfter = this.arrays[i].after;
                                    break;
                                default:
                            }
                        }
                        this.config("move");
                        this.bindFun();
                        if(this.arrays[0].completes){
                           this.arrays[0].completes($this);
                        }
                    }else{
                        $.error = console.error;
                        $.error("参数格式不正确！");
                    }
                },
                config: function(str) {
                    var that = this,i=0,butArr=that.but.split(","),
                        con = that.arrays[0].config,
                        arr = (con.type == "top" ? ["top"] : ["left"]);
                    if (con.type == "left" || con.type == "top") {
                        if (con.type == "left") {
                            that.ul.addClass("uiRollFloat");
                            that.ul.width($this.width() * that.li.length);
                        }
                        if (that.list == that.li.length) {
                            con.type == "top" ? that.li.first().css(arr[0], that.ul.height()) : that.li.first().css(arr[0], that.ul.width());//给第一张图片的position: relative;赋值以达到无限循环效果
                            that.callback = function() {
                                that.li.first().css(arr[0], 0);
                                that.ul.css(arr[0], 0);
                                that.list = 0;
                            }
                        }
                        if (that.list == -1) {
                            con.type == "top" ? that.li.last().css(arr[0], -that.ul.height()) : that.li.last().css(arr[0], -that.ul.width());//给最后张图片的position: relative;赋值以达到无限循环效果
                            that.callback = function() {
                                that.list = that.li.length - 1;
                                that.li.last().css(arr[0], 0);
                                con.type == "top" ? that.ul.css(arr[0], -parseInt($this.height()) * that.list) : that.ul.css(arr[0], -parseInt($this.width()) * that.list);
                            }
                        }
                        that.scrollA();
                    } else if (con.type == "fade") {
                        if (!that.ul.hasClass("uiRollPost")) {
                            that.ul.addClass("uiRollPost")
                        }
                        if (that.list == that.li.length) {
                            that.list = 0;
                        }
                        that.fadeFun();
                    }

                    for(;i<butArr.length;i++){
                        $(butArr[i]).eq(that.list == that.li.length ? 0 : that.list).siblings().removeClass("on");//按钮样式变化
                        $(butArr[i]).eq(that.list == that.li.length ? 0 : that.list).addClass("on");//按钮样式变化
                    }
                },
                scrollA: function() {
                    this.animated = true;
                    var that = this, textCss,
                            con = that.arrays[0].config;
                    clearTimeout(that.t);
                    that.rerurnFun(0);
                    con.type == "top" ? textCss = {"top": -parseInt($this.height()) * that.list} : textCss = {"left": -parseInt($this.width()) * that.list};//获取滚动值
                    that.ul.stop(true).textAnimation({"css": textCss, "config": con, callback: function() {
                            if (that.callback) {
                                that.callback();
                                that.callback = null;
                            }
                            that.animated = false;
                            that.rerurnFun(1);
                        }});
                    that.setTime();
                },
                fadeFun: function() {
                    var that = this;
                    clearTimeout(that.t);
                    that.rerurnFun(0);
                    that.li.css('opacity', 1)
                    that.li.eq(that.list).siblings().stop(true).fadeOut(that.arrays[0].config.speed);
                    that.li.eq(that.list).fadeIn(that.arrays[0].config.speed,function(){
                        that.rerurnFun(1);
                    });
                   that.setTime();
                },
                bindFun: function() {
                    var that = this;
                    $(that.but).hover(function() {
                        that.list = $(this).index();
                        that.config("stop");
                        clearTimeout(that.t);
                    },function(){
                        that.setTime();
                    });

                    that.li.hover(function(){
                       clearTimeout(that.t);
                    },function(){
                       that.setTime();
                    });

                    if (that.arrays[0].config.button) {
                        $$(".J_ui_butPost_a").click(function() {
                            if(that.animated){
                                return false;
                            }else{
                              that.list -= 1;
                              that.config("move");
                            }
                        });
                        $$(".J_ui_butPost_b").click(function() {
                            if(that.animated){
                                return false;
                            }else{
                              that.list += 1;
                              that.config("move");
                            }
                        });
                    } else {
                        $$(".J_ui_butPost_b").remove();
                        $$(".J_ui_butPost_a").remove();
                    }
                },
                rerurnFun: function(num) {
                    if(num){
                      !!this.returnAfter && this.returnAfter(this.list == this.li.length?0:this.list);
                    }else{
                      !!this.returnBefore && this.returnBefore(this.list == this.li.length?0:this.list);
                    }
                },
                setTime: function() {
                    var that = this;
                    that.t = setTimeout(function() {
                        that.list += 1;
                        that.config("move");
                    }, that.arrays[0].config.time);
                }
            }
            animates.init.apply(animates, arg);
        });
    }
    var defaults = {css: {"top": 0}, config: {speed: 800, easing: "swing", time: 0}},
    textAnimation = function(a) {
        return this.each(function() {
            var $this = $(this),
                    settings = $.extend(true,{}, defaults, a);
            $this.animate(settings.css, settings.config.speed, settings.config.easing, function() {
                !!settings.callback && settings.callback();
            });
        })
    };
    $.extend(Array.prototype, {
        has: function(value) {
            return this.index(value) !== -1;
        },
        index: function(value) {
            if (this.indexOf) {
                return this.indexOf(value);
            }
            for (var i = 0, l = this.length; i < l; i++) {
                if (value == this[i]) {
                    return i;
                }
            }
            return -1;
        }
    });
    $.fn.extend({
        textAnimation:textAnimation,
        slide: picScroll,
        imagesLoaded:function(a) {//判断图片是否加载完成
            var b = $;
            function h() {
                a.call(c, d)
            }
            function i(a) {
                var c = a.target;
                c.src !== f && b.inArray(c, g) === -1 && (g.push(c), --e <= 0 && (setTimeout(h), d.unbind(".imagesLoaded", i)))
            }
            var c = this,
            d = c.find("img").add(c.filter("img")),
            e = d.length,
            f = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==",
            g = [];
            return e || h(),
            d.bind("load.imagesLoaded error.imagesLoaded", i).each(function() {
                var a = this.src;
                this.src = f,
                this.src = a
            }),
            c
        }
    });
})(jQuery);