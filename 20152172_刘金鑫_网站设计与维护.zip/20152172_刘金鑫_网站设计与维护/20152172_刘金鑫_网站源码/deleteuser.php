
<?php  
@$db = new PDO("mysql:host=localhost;dbname=user","root","");

$username = $_GET['username'];
  
$stmt=$db->prepare("DELETE FROM user WHERE username=?");
$stmt->bindParam(1,$username);
$stmt->execute();
if($stmt->rowCount() >=1){
  echo "<script>alert('删除成功');";
  echo("location.href='guanli.php';");
  echo('</script>');
}else{
  echo "<script>alert('删除失败');";
  echo("location.href='guanli.php';");
  echo('</script>');
}

?>
