<?php session_start()?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="keywords" content="20152172 刘金鑫">
	<meta name="descraption" content="天津理工大学计算机科学与工程学院 刘金鑫">
	<link rel="icon" href="images/ico.jpg" type="image/x-icon" />
	<link rel="stylesheet" type="text/css" href="style.css">
	<script src="jquery-2.2.1.min.js" type="text/javascript"></script>
	<script type="text/javascript">
		window.onload = function(){
			var login2333 = document.getElementById("login_button");
			var login233 = document.getElementById("sign_up_button");
			var login23333 = document.getElementById("upload_button");
			var login233333 = document.getElementById("logout_button");


			if(login2333){
			login2333.addEventListener("click",function(event){
				
				document.getElementById("false2").style="display:none";
				document.getElementById("false1").style="display:block;float:left;position:absolute;margin-left: 40%;margin-top:-300px;height:300px;width:360px;background: #fff;";
			},false);
			}

			if(login233){
			login233.addEventListener("click",function(event){
				
				document.getElementById("false1").style="display:none";
				document.getElementById("false2").style="display:block;float:left;position:absolute;margin-left: 40%;margin-top:-300px;height:300px;width:360px;background: #fff;";
			},false);
			}
			login23333.addEventListener("click",function(event){
				window.open('shangchuan.html');
			})
			
			login233333.addEventListener("click",function(event){
				window.location.href='logout.php';

			})
		}

	</script>
	<style>  
        table{  
            border-collapse: collapse;  
        }  
        th,td{  
            border:1px solid #ccccff;  
            padding: 5px;  
        }  
        td{  
            text-align: center;  
        }  
    </style>
	<title>网站设计与维护</title>
</head>
<body>
<div class="ljx-main">
<div class="head-area clearfix">
<div class="area-main">
	<a href="index.php">
		<img src="images/beibao.jpg" alt="logo" id="logo">
	</a>
		<script>
		var today = new Date();
		var hourNow = today.getHours();
		var greeting;

		if (hourNow > 18) {
    	greeting = '晚上好，管理员!';
		} else if (hourNow > 10) {
    	greeting = '下午好，管理员!';
		} else if (hourNow >= 0 ) {
    	greeting = '早上好，管理员!';
		} else {
    	greeting = 'Welcome!';
		}

		document.write('<span class="greeting" style="text-shadow: -2px 5px 11px white;">' + greeting + '</span>');
		</script>

</div>


</div>
<div class="header-area">
<div class="header-main clearfix">
	<ul class="fl">
	<li class="">
		<a class="on" href="index.php">开车</a>
	</li>
	<li class="">
		<a href="#">水群</a>
		<div class="belongs">
		<a class="li" href="#">ACFUN</a>
		<a class="li" href="#">ACDREAM</a>
		<a class="li" href="#">ACMer求职</a>
			
		</div>
	</li>
	<li class="">
		<a href="#">HDOJ</a>
		<div class="belongs">
		<a class="li" href="#">BestCoder</a>
		<a class="li" href="#">HDOJ水题</a>
			
		</div>
	</li>
	<li class="">
		<a href="#">POJ</a>
		<div class="belongs">
		<a class="li" href="#">水友赛</a>
		<a class="li" href="#">奖品</a>
		
		</div>
	</li>
	
	<li class="">
		<a href="#">ICPC</a>
		<div class="belongs">
		<a class="li" href="#">划水区</a>
		<a class="li" href="#">打铁</a>			
		</div>
	</li>
	<li class="">
		<a href="#" target="_blank">CCPC</a>
		<div class="belongs">
		<a class="li" href="#" target="_blank">报名</a>

		</div>
	</li>
    
	</ul>
	

	<script type="text/javascript">
		 $(".header-area .header-main li").on("mouseover", function(){
                $(".header-area .header-main .onthis").removeClass("onthis");
                $(this).addClass("onthis");
            });
            $(".header-area .header-main li").on("mouseleave", function(){
                $(".onthis").removeClass("onthis");
            })
	</script>
    


    	<div id="login" >
				<a>
					<img class="login_logo" src="images\person_mini.png">
					<?php
        				
        				if(@$_SESSION["isLogin"]===1)
        				{
           					@$username=$_SESSION["username"];
            				echo "
            				<div class='login_hidden' >
								<div class='logout_button'>
								<button 
									id = 'logout_button';
									style='
									overflow: hidden;
									height:40px;
									width:108px;
									border-radius: 8px;
									text-align: center;
									margin-top:100px;
									margin-left: 30px;
									float:left;
									color:#fff;
									border: 1px solid #7794e8;
									background-color: #88aff8;
									background-image: linear-gradient(#88aff8,#7794e8);'
									>
									Logout
								</button>

								<button 
									id = 'username_button';
									style='
									overflow: hidden;
									height:40px;
									width:108px;
									border-radius: 8px;
									text-align: center;
									margin-top:100px;
									margin-left: 10px;
									float:left;
									color:#fff;
									border: 1px solid #7794e8;
									background-color: #88aff8;
									background-image: linear-gradient(#88aff8,#7794e8);'>
									你好 $username
								</button>
								<button 
									id = 'upload_button';
									style='
									overflow: hidden;
									height:40px;
									width:108px;
									border-radius: 8px;
									text-align: center;
									margin-top:100px;
									margin-left: 30px;
									float:left;
									color:#fff;
									border: 1px solid #7794e8;
									background-color: #88aff8;
									background-image: linear-gradient(#88aff8,#7794e8);'
									>

									Upload
								</button>
							</div>
						</div>
						";
        				}
        				else{
            				echo "
            				<div class='login_hidden' >
								<div class='login_button'>
								<button 
									id = 'login_button';
									style='
									overflow: hidden;
									height:40px;
									width:108px;
									border-radius: 8px;
									text-align: center;
									margin-top:100px;
									margin-left: 30px;
									float:left;
									color:#fff;
									border: 1px solid #7794e8;
									background-color: #88aff8;
									background-image: linear-gradient(#88aff8,#7794e8);'
									onclick='window.location.href='login.php' '>
									Login
								</button>

								<button 
									id = 'sign_up_button';
									style='
									overflow: hidden;
									height:40px;
									width:108px;
									border-radius: 8px;
									text-align: center;
									margin-top:100px;
									margin-left: 10px;
									float:left;
									color:#fff;
									border: 1px solid #7794e8;
									background-color: #88aff8;
									background-image: linear-gradient(#88aff8,#7794e8);'													
									onclick='window.location.href='reg.php' '>
									Sign up
								</button>


								<button 
									id = 'upload_button';
									style='
									overflow: hidden;
									height:40px;
									width:108px;
									border-radius: 8px;
									text-align: center;
									margin-top:100px;
									margin-left: 10px;
									float:left;
									color:#fff;
									border: 1px solid #7794e8;
									background-color: #88aff8;
									background-image: linear-gradient(#88aff8,#7794e8);'
									>

									Upload
								</button>
							
								</div>
							</div>	";
						}
    				?>
    				
							
				</a>
			</div>

	
</div>	
</div>


 
<table style=" margin: auto auto auto 520px ; font-size: 36px; color: white;">  
    <tr><th>username</th><th>password</th><th>删除</th></tr>  
<?php
if(@$_SESSION["username"]=="admin"){
	@$db = new PDO("mysql:host=localhost;dbname=user","root","");
	$stmt = $db->prepare("SELECT * FROM user");
	$stmt->execute();
	$r = $stmt->fetchAll(PDO::FETCH_ASSOC);
	foreach($r as $i){
		echo "<tr><td>".$i["username"]."</td><td>".$i["passwd"]."</td> <td> <a href='deleteuser.php?username=".$i["username"]."'>删除</a></td></tr>";

	}
}else{
	echo "<script>alert('非法访问，拒绝');";
	echo("setTimeout(function(){location.href=\"index.php\";},2);</script>");
	exit();
}

?>
</table>

<div class="left-photo" style="left: -200px; top:100px; width: 150px;">
		<img src="images/cebianlan.jpg" alt="cebianlan">
	</div>
	<div class="right-photo" style="right: 100px;bottom:120px; position:fixed;">
		<img src="images/naotou.jpg" alt="naotou" width="150px">
		<div style="background-color: #fff;width:150px; text-align: center; font-size: 20px;"><a href="#top">返回顶部</a></div>
		
	</div>
</div>

</body>
</html>