<?php session_start()?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="keywords" content="20152172 刘金鑫">
	<meta name="descraption" content="天津理工大学计算机科学与工程学院 刘金鑫">
	<link rel="icon" href="images/ico.jpg" type="image/x-icon" />
	<link rel="stylesheet" type="text/css" href="style.css">
	<script src="jquery-2.2.1.min.js" type="text/javascript"></script>
	<script type="text/javascript">
		window.onload = function(){
			var login2333 = document.getElementById("login_button");
			var login233 = document.getElementById("sign_up_button");
			var login23333 = document.getElementById("upload_button");
			var login233333 = document.getElementById("logout_button");
			var login2333333 = document.getElementById("admin_button");


			if(login2333){
			login2333.addEventListener("click",function(event){
				
				document.getElementById("false2").style="display:none";
				document.getElementById("false1").style="display:block;float:left;position:absolute;margin-left: 40%;margin-top:-300px;height:300px;width:360px;background: #fff;";
			},false);
			}

			if(login233){
			login233.addEventListener("click",function(event){
				
				document.getElementById("false1").style="display:none";
				document.getElementById("false2").style="display:block;float:left;position:absolute;margin-left: 40%;margin-top:-300px;height:300px;width:360px;background: #fff;";
			},false);
			}
			login23333.addEventListener("click",function(event){
				window.open('shangchuan.php');
			})
			
			login233333.addEventListener("click",function(event){
				window.location.href='logout.php';

			})
			login2333333.addEventListener("click",function(event){
				window.location.href='guanli.php';

			})
		}

	</script>
	<title>网站设计与维护</title>
</head>
<body>
<div class="ljx-main" style="background-image: url(images/bgtop.jpg) no-repeat width:1280PX;">
<div class="head-area clearfix">
<div class="area-main">
	<a href="index.php">
		<img src="images/beibao.jpg" alt="logo" id="logo">
	</a>
		<script>
		var today = new Date();
		var hourNow = today.getHours();
		var greeting;

		if (hourNow > 18) {
    	greeting = '晚上好，ACMer!';
		} else if (hourNow > 10) {
    	greeting = '下午好，ACMer!';
		} else if (hourNow >= 0 ) {
    	greeting = '早上好，ACMer!';
		} else {
    	greeting = 'Welcome!';
		}

		document.write('<span class="greeting" style="text-shadow: -2px 5px 11px white;">' + greeting + '</span>');
		</script>

</div>


</div>
<div class="header-area">
<div class="header-main clearfix">
	<ul class="fl">
	<li class="">
		<a class="on" href="index.php">开车</a>
	</li>
	<li class="">
		<a href="#">水群</a>
		<div class="belongs">
		<a class="li" href="#">ACFUN</a>
		<a class="li" href="#">ACDREAM</a>
		<a class="li" href="#">ACMer求职</a>
			
		</div>
	</li>
	<li class="">
		<a href="#">HDOJ</a>
		<div class="belongs">
		<a class="li" href="#">BestCoder</a>
		<a class="li" href="#">HDOJ水题</a>
			
		</div>
	</li>
	<li class="">
		<a href="#">POJ</a>
		<div class="belongs">
		<a class="li" href="#">水友赛</a>
		<a class="li" href="#">奖品</a>
		
		</div>
	</li>
	
	<li class="">
		<a href="#">ICPC</a>
		<div class="belongs">
		<a class="li" href="#">划水区</a>
		<a class="li" href="#">打铁</a>			
		</div>
	</li>
	<li class="">
		<a href="#" target="_blank">CCPC</a>
		<div class="belongs">
		<a class="li" href="#" target="_blank">报名</a>

		</div>
	</li>
    
	</ul>
	

	<script type="text/javascript">
		 $(".header-area .header-main li").on("mouseover", function(){
                $(".header-area .header-main .onthis").removeClass("onthis");
                $(this).addClass("onthis");
            });
            $(".header-area .header-main li").on("mouseleave", function(){
                $(".onthis").removeClass("onthis");
            })
	</script>
    


    	<div id="login" >
				<a>
					<img class="login_logo" src="images\person_mini.png">
					<?php
        				
        				if(@$_SESSION["isLogin"]===1)
        				{
           					@$username=$_SESSION["username"];
           					if($username=='admin')
           					{
           						echo "
            				<div class='login_hidden' >
								<div class='logout_button'>
								<button 
									id = 'logout_button';
									style='
									overflow: hidden;
									height:40px;
									width:108px;
									border-radius: 8px;
									text-align: center;
									margin-top:100px;
									margin-left: 30px;
									float:left;
									color:#fff;
									border: 1px solid #7794e8;
									background-color: #88aff8;
									background-image: linear-gradient(#88aff8,#7794e8);'
									>
									Logout
								</button>

								<button 
									id = 'username_button';
									style='
									overflow: hidden;
									height:40px;
									width:108px;
									border-radius: 8px;
									text-align: center;
									margin-top:100px;
									margin-left: 10px;
									float:left;
									color:#fff;
									border: 1px solid #7794e8;
									background-color: #88aff8;
									background-image: linear-gradient(#88aff8,#7794e8);'>
									你好 $username
								</button>
								<button 
									id = 'upload_button';
									style='
									overflow: hidden;
									height:40px;
									width:108px;
									border-radius: 8px;
									text-align: center;
									margin-top:100px;
									margin-left: 30px;
									float:left;
									color:#fff;
									border: 1px solid #7794e8;
									background-color: #88aff8;
									background-image: linear-gradient(#88aff8,#7794e8);'
									>

									Upload
								</button>
								<button 
									id = 'admin_button';
									style='
									overflow: hidden;
									height:40px;
									width:108px;
									border-radius: 8px;
									text-align: center;
									margin-top:100px;
									margin-right: 100px;
									float:right;
									color:#fff;
									border: 1px solid #7794e8;
									background-color: #88aff8;
									background-image: linear-gradient(#88aff8,#7794e8);'
									>

									管理
								</button>
							</div>
						</div>
						";
           					}
           					else{
           						echo "
            				<div class='login_hidden' >
								<div class='logout_button'>
								<button 
									id = 'logout_button';
									style='
									overflow: hidden;
									height:40px;
									width:108px;
									border-radius: 8px;
									text-align: center;
									margin-top:100px;
									margin-left: 30px;
									float:left;
									color:#fff;
									border: 1px solid #7794e8;
									background-color: #88aff8;
									background-image: linear-gradient(#88aff8,#7794e8);'
									>
									Logout
								</button>

								<button 
									id = 'username_button';
									style='
									overflow: hidden;
									height:40px;
									width:108px;
									border-radius: 8px;
									text-align: center;
									margin-top:100px;
									margin-left: 10px;
									float:left;
									color:#fff;
									border: 1px solid #7794e8;
									background-color: #88aff8;
									background-image: linear-gradient(#88aff8,#7794e8);'>
									你好 $username
								</button>
								<button 
									id = 'upload_button';
									style='
									overflow: hidden;
									height:40px;
									width:108px;
									border-radius: 8px;
									text-align: center;
									margin-top:100px;
									margin-left: 30px;
									float:left;
									color:#fff;
									border: 1px solid #7794e8;
									background-color: #88aff8;
									background-image: linear-gradient(#88aff8,#7794e8);'
									>

									Upload
								</button>
							</div>
						</div>
						";
           					}
            				
        				}
        				else{
            				echo "
            				<div class='login_hidden' >
								<div class='login_button'>
								<button 
									id = 'login_button';
									style='
									overflow: hidden;
									height:40px;
									width:108px;
									border-radius: 8px;
									text-align: center;
									margin-top:100px;
									margin-left: 30px;
									float:left;
									color:#fff;
									border: 1px solid #7794e8;
									background-color: #88aff8;
									background-image: linear-gradient(#88aff8,#7794e8);'
									onclick='window.location.href='login.php' '>
									Login
								</button>

								<button 
									id = 'sign_up_button';
									style='
									overflow: hidden;
									height:40px;
									width:108px;
									border-radius: 8px;
									text-align: center;
									margin-top:100px;
									margin-left: 10px;
									float:left;
									color:#fff;
									border: 1px solid #7794e8;
									background-color: #88aff8;
									background-image: linear-gradient(#88aff8,#7794e8);'													
									onclick='window.location.href='reg.php' '>
									Sign up
								</button>


								<button 
									id = 'upload_button';
									style='
									overflow: hidden;
									height:40px;
									width:108px;
									border-radius: 8px;
									text-align: center;
									margin-top:100px;
									margin-left: 30px;
									float:left;
									color:#fff;
									border: 1px solid #7794e8;
									background-color: #88aff8;
									background-image: linear-gradient(#88aff8,#7794e8);'
									>

									Upload
								</button>
							
								</div>
							</div>	";
						}
    				?>
    				
							
				</a>
		</div>

	
</div>	
</div>


<div class="content-box" >
	<div class="left-photo" style="left: -200px; top:100px; width: 150px;">
		<img src="images/cebianlan.jpg" alt="cebianlan">
	</div>
	<div class="right-photo" style="right: 100px;bottom:120px; position:fixed;">
		<img src="images/naotou.jpg" alt="naotou" width="150px">
		<div style="background-color: #fff;width:150px; text-align: center; font-size: 20px;"><a href="#top">返回顶部</a></div>
		
	</div>
	<div class="js_slide">
            <div class="roll" style="width: 960px; height: 540px;">
                <ul class="uiRoll uiRollFloat" style="left: -2880px; top: 0px; width: 6720px;">
                        <li style="width: 960px; height: 540px;">
                            <a href="#">
                                <img src="images/quality.jpg">
                            </a>f
                        </li>
                        <li style="width: 960px; height: 540px;">
                            <a href="#">
                                <img src="images/acm.jpg">
                            </a>
                        </li>
                      	<li style="width: 960px; height: 540px;">
                            <a href="#">
                                <img src="images/baocuo.jpg">
                            </a>
                        </li>
                        <li style="width: 960px; height: 540px;">
                            <a href="#">
                                <img src="images/cwyz.jpg">
                            </a>
                        </li>
                        <li style="width: 960px; height: 540px;">
                            <a href="#">
                                <img src="images/acm2.jpg">
                            </a>
                        </li>

                </ul>
                <ul class="ui_1">
                    <li class="on"></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                                            
                </ul>
                <div class="textdiv">
                    <div class="bgs"></div>
                    <div class="textdiv_in" style="display: none;">
                    	<a href="#" target="_blank">%%%Q神</a>
                    </div>
                    <div class="textdiv_in" style="display: none;">
                    	<a href="#" target="_blank">你天天搞ACM能找到女朋友吗？</a>
                    </div>
                    <div class="textdiv_in" style="display: none;">
                    	<a href="#" target="_blank">0 Errors, 0 Warning</a>
                    </div>
                    <div class="textdiv_in" style="display: block;">
                    	<a href="#" target="_blank">吃我一招</a>
                    </div>
                    <div class="textdiv_in">
                    	<a href="#" target="_blank">这题能做？</a>
                    </div>
                                       
                </div>
               
            </div>
         <script type="text/javascript" src="index.js"></script>
        </div>

</div>




<?php
    if(@$_SESSION["isLogin"]===1){
        
    }
    if(isset($_POST["username"])&&isset($_POST["passwd"])){
        $username = $_POST["username"];
        $passwd = $_POST["passwd"];
        $db = new PDO("mysql:host=localhost;dbname=user","root","");
        $stmt = $db->query("SELECT passwd FROM user WHERE username='$username'");
        $pass = $stmt->fetch(PDO::FETCH_NUM)[0];
        if(empty($pass)){

            echo('<script language="JavaScript">');
            echo('alert("用户不存在，请注册");');
            echo("location.href='index.php';");
            echo('</script>');
            exit();
        }
        if($passwd===$pass){
            $_SESSION["isLogin"]=1;
            $_SESSION["username"]=$username;
            echo('<script language="JavaScript">');
            echo("location.href='index.php';");
            echo('</script>');
        }else{
            echo('<script language="JavaScript">');
            echo('alert("密码错误");');
            echo("location.href='index.php';");
            echo('</script>');
            exit();
        }
    }
?>
<div class = "hid_login" id="false1" 
	style="
		display:none;
		float:left;
		height:100px;
		margin-left: 40%;
		width:300px;
		background: #fff">
	<form method="post" style="margin: 50px auto auto 80px">
        <p>用户名：</p><input type="text" name="username">
        <p>密码：</p><input type="password" name="passwd">
        <br><br>
        <input type="submit" style="overflow: hidden;
									height:40px;
									width:108px;
									border-radius: 8px;
									text-align: center;
									float:left;
									color:#fff;
									border: 1px solid #7794e8;
									background-color: #88aff8;
									background-image: linear-gradient(#88aff8,#7794e8);" value="登录">
    </form>
    <br><br>

</div>



<div class = "hid_signin" id="false2" 
	style="
		display:none;
		float:left;
		margin-left: 40%;
		height:100px;
		width:300px;
		background-color: #fff">
	<form action ="reg.php" method="post" style="margin: 50px auto auto 80px">
		<p>用户名：</p><input type="text" name="username">
		<p>密码：</p><input type="password" name="passwd">
		<br><br>
		<input type="submit" style="overflow: hidden;
									height:40px;
									width:108px;
									border-radius: 8px;
									text-align: center;
									float:left;
									color:#fff;
									border: 1px solid #7794e8;
									background-color: #88aff8;
									background-image: linear-gradient(#88aff8,#7794e8);" value="注册">
	</form>
</div>



<section class="t-block" id="jieshao" >
				<h5>
					各大OJ介绍
				</h5>
				<ul>
					<li class="width-1 getshadow">
						<img src="images/hdoj.png" width="245" height="156">
						<div class="info">
							<h6>
								杭电OnlineJudgement
							</h6>
						</div>
						<p>
							Welcome to HDU Online Judge System
						</p>
						<span>
							<a href="#">
								访问>
							</a>
						</span>
					</li>
					<li class="width-1 getshadow">
						<img src="images/poj.png" width="245" height="156">
						<div class="info">
							<h6>
								PKU Online Judge
							</h6>
						</div>
						<p>
							Problem Set is the place where you can find large amount of problems from different programming contests.Online Judge System allows you to test your solution for every problem.

  							First of all, read carefully Frequently Asked Questions.
  							Then, choose a problem, solve it and submit your solution.

  							If you want to publish your problems or setup your own online contest, just write us.
						</p>
						<span>
							<a href="#">
								访问>
							</a>
						</span>
					</li>
					<li class="width-1 getshadow">
						<img src="images/bzoj.png" width="245" height="156">
						<div class="info">
							<h6>
								bzoj-大视野在线评测
							</h6>
						</div>
						<p>
							Notice:1:欢迎光临本站资源站http://lydsy.youhaovip.com/products,另本站提供各级各类比赛备战资源，有意者请联系Lydsy2012@163.com 2:今后但凡有人恶意卡测评，将封锁其网段IP
						</p>
						<span>
							<a href="#">
								访问>
							</a>
						</span>
					</li>
					<li class="width-1 getshadow">
						<img src="images/cf.png" width="245" height="156">
						<div class="info">
							<h6>
								Codeforces
							</h6>
						</div>
						<p>
							Hello everybody!

							Congratulations to the platform Codeforces with an Anniversary 450th round!
							We are glad to report that Codeforces Round #450 (Div.2) takes place on December 11 19:05 MSK. The round will be rated for Div.2 participants. Traditionally, we invite Div.1 participants to join out of competition. I hope stronger participants also will find interesting problems for themselves:)
							The problems are created by me and Nikita slelaron Kostlivcev. We want to show our great appreciation to Nikolay KAN Kalinin for round coordination, mike_live and Arpa for testing the problems and of course Mike MikeMirzayanov Mirzayanov for great platforms Codeforces and Polygon.
							You will have 5 problems to solve in 2 hours.
							Scoring as usual: 500 — 1000 — 1500 — 2000 — 2500.
							Good luck to all and enjoy the problems!
							UPD: Contest is finished! I hope you enjoyed the round:)
							UPD: Editorial. The problem E will be posted soon.
							Congratulations to the winners!!!
						</p>
						<span>
							<a href="#">
								访问>
							</a>
						</span>
					</li>
				</ul>
			
			</section>	






</div>

</body>
<footer style="background-color: #aaa;width:100%;height: 50px; text-align: center;font-size: 25px;">
	2017- Copyright
</footer>
</html>