<?php
    session_start();
	// if(isset($_SESSION["isLogin"])&&$_SESSION["isLogin"]==1){
	//     echo "已经登陆";
	//     exit();
 //    }
    if(isset($_POST["username"])&&isset($_POST["passwd"])){
	    $username = $_POST["username"];
	    $passwd = $_POST["passwd"];
	    @$db = new PDO("mysql:host=localhost;dbname=user","root","");
	    $db->exec("INSERT INTO user VALUES ('$username','$passwd')");

        echo('<script language="JavaScript">');
       	echo "alert('注册成功');";
        echo("setTimeout(function(){location.href=\"index.php\";},2);");
        echo('</script>');
        exit();
    }
?>
