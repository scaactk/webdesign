<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="keywords" content="20152172 刘金鑫">
	<meta name="descraption" content="天津理工大学计算机科学与工程学院 刘金鑫">
	<link rel="icon" href="images/ico.jpg" type="image/x-icon" />
	<link rel="stylesheet" type="text/css" href="style.css">
	<script src="jquery-2.2.1.min.js" type="text/javascript"></script>
	<script type="text/javascript">
		window.onload = function(){
			var login233 = document.getElementById("login_botton");
			login233.addEventListener("click",function(event){
				document.getElementById("denglu_form").submit();
			},false);
		}
	</script>
	<title>网站设计与维护</title>
</head>
<body>
<div class="gty-main">
<div class="head-area clearfix">
<div class="area-main">
	<a href="index.html">
		<img src="images/beibao.jpg" alt="logo" id="logo">
	</a>
		<script>
		var today = new Date();
		var hourNow = today.getHours();
		var greeting;

		if (hourNow > 18) {
    	greeting = '晚上好，ACMer!';
		} else if (hourNow > 10) {
    	greeting = '下午好，ACMer!';
		} else if (hourNow >= 0 ) {
    	greeting = '早上好，ACMer!';
		} else {
    	greeting = 'Welcome!';
		}

		document.write('<span class="greeting" style="text-shadow: -2px 5px 11px white;">' + greeting + '</span>');
		</script>

</div>


</div>
<div class="header-area">
<div class="header-main clearfix">
	<ul class="fl">
	<li class="">
		<a class="on" href="index.php">开车</a>
	</li>
	<li class="">
		<a href="#">水群</a>
		<div class="belongs">
		<a class="li" href="#">ACFUN</a>
		<a class="li" href="#">ACDREAM</a>
		<a class="li" href="#">ACMer求职</a>
			
		</div>
	</li>
	<li class="">
		<a href="#">HDOJ</a>
		<div class="belongs">
		<a class="li" href="#">BestCoder</a>
		<a class="li" href="#">HDOJ水题</a>
			
		</div>
	</li>
	<li class="">
		<a href="#">POJ</a>
		<div class="belongs">
		<a class="li" href="#">水友赛</a>
		<a class="li" href="#">奖品</a>
		
		</div>
	</li>
	
	<li class="">
		<a href="#">ICPC</a>
		<div class="belongs">
		<a class="li" href="#">划水区</a>
		<a class="li" href="#">打铁</a>			
		</div>
	</li>
	<li class="">
		<a href="#" target="_blank">CCPC</a>
		<div class="belongs">
		<a class="li" href="#" target="_blank">报名</a>

		</div>
	</li>
    
	</ul>
	

	<script type="text/javascript">
		 $(".header-area .header-main li").on("mouseover", function(){
                $(".header-area .header-main .onthis").removeClass("onthis");
                $(this).addClass("onthis");
            });
            $(".header-area .header-main li").on("mouseleave", function(){
                $(".onthis").removeClass("onthis");
            })
	</script>
    


    	<div id="login" >
				<a>
					<img class="login_logo" src="images\person_mini.png">
									
					<div class="login_hidden"  >
						<!-- <form id="denglu_form" action="login.php" method="get" style="margin-left: 20px; margin-top: 50px;float: left;">
							Username: 
							<input id = "uer_name" type="text" name="Username" />
							<br/>
							Password:
							 <input id = "user_password" type="text" name="Password" />
							<br/>
						</form>	 -->
						<div class="login_botton">
							<button 
									id = "login_botton";
									style="
									overflow: hidden;
									height:40px;
									width:108px;
									border-radius: 8px;
									text-align: center;
									margin-top:100px;
									margin-left: 30px;
									float:left;
									color:#fff;
									border: 1px solid #7794e8;
									background-color: #88aff8;
									background-image: linear-gradient(#88aff8,#7794e8);"
									onclick="window.location.href='login.php' ">
									Login
							</button>
							<button 
									id = "sign_in_button";
									style="
									overflow: hidden;
									height:40px;
									width:108px;
									border-radius: 8px;
									text-align: center;
									margin-top:100px;
									margin-left: 10px;
									float:left;
									color:#fff;
									border: 1px solid #7794e8;
									background-color: #88aff8;
									background-image: linear-gradient(#88aff8,#7794e8);"
									onclick="window.location.href='reg.php' ">
									Sign in
							</button>
							<button 
									id = "update";
									style="
									overflow: hidden;
									height:40px;
									width:108px;
									border-radius: 8px;
									text-align: center;
									margin-top:100px;
									margin-left: 30px;
									float:left;
									color:#fff;
									border: 1px solid #7794e8;
									background-color: #88aff8;
									background-image: linear-gradient(#88aff8,#7794e8);"
									onclik = "window.location.href= 'shanchuan.php' ">
									upload
							</button>
						</div>
					</div>
				</a>
			</div>

	
</div>	
</div>
<div id="sc" style="margin:auto 25%; background-color: #fff; width: 600px;height: 200px;font-size: 25px; padding: 10px 10% 10px 10%; border-radius:25px;">
	<form action="file.php" method="post" enctype="multipart/form-data">
	<label for="file" >文件名：</label>
	<input type="file" name="file" id="file"><br>
	只允许上传图片格式文件<br>
	<input type="submit" name="submit" value="提交" style="width:100px; height:100px;">
	</form>
</div>





</div>

</body>
</html>